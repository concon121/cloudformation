//-- Prudential specific functions --//

function PruMath() {
};

/**
 * Round decimal down a decimal input - ie round down at 50p
 * 
 * @method roundDown
 * @param {number} a the number to be rounded
 * @param {number} b the decimal places to be returned (e.g. 1 = no dec place, 10 = 1 dec place, 100 = 2 dec place etc.)
 * @return {number} The rounded number
 */
PruMath.roundDown = function(a, b) {
	var intPart = Math.floor(a * b), decPart = (a * b - intPart), decPartFixed = Number(decPart.toString().match(/^\d+(?:\.\d{0,2})?/));
	if (decPartFixed > 0.5) {
		return Math.ceil(intPart + decPart) / b;
	} else {
		return Math.floor(intPart + decPart) / b;
	}
};

/**
 * Round decimal up a decimal input - ie round up at 50p
 * 
 * @method roundUp
 * @param {number} a the number to be rounded
 * @param {number} b the decimal places to be returned (e.g. 1 = no dec place, 10 = 1 dec place, 100 = 2 dec place etc.)
 * @return {number} The rounded number
 */
PruMath.roundUp = function(a, b) {
	var intPart = Math.floor(a * b), decPart = (a * b - intPart), decPartFixed = Number(decPart.toFixed(3).toString().match(/^\d+(?:\.\d{0,3})?/));
	var returnNum = 0;
	if (decPartFixed >= 0.5) {
		returnNum =  Math.ceil(intPart + decPart) / b;
	} else {
		returnNum =  Math.floor(intPart + decPart) / b;
	}
	return returnNum;
};

/**
 * Round up at 50p 
 * 
 * @method roundUpAtFifty
 * @param {number} a the number to be rounded
 * @return {number} The rounded number
 */
PruMath.roundUpAtFifty = function(a) {
	
	var intPart = Math.floor(a), decPart = (a - intPart);
	var returnNum = 0;
	if (decPart >= 0.5) {
		returnNum =  Math.ceil(intPart + decPart);
	} else {
		returnNum =  Math.floor(intPart + decPart);
	}
	return returnNum;
};

/**
 * Round down at 50p
 * 
 * @method roundDownAtFifty
 * @param {number} a the number to be rounded
 * @return {number} The rounded number
 */
PruMath.roundDownAtFifty = function(a) {
	 
	var intPart = Math.floor(a), decPart = (a - intPart);
	var returnNum = 0;
	if (decPart <= 0.5) {
		returnNum =  Math.floor(intPart + decPart);
	} else {
		returnNum =  Math.ceil(intPart + decPart);
	}
	return returnNum;
};

/**
 * Round down at 50 pounds
 * 
 * @method roundDownAtFiftyPounds
 * @param {number} a the number to be rounded
 * @return {number} The rounded number
 */
PruMath.roundDownAtFiftyPounds = function(a) {
	 
	var b = 0.01, intPart = Math.floor(a * b), decPart = (a * b - intPart);
	var returnNum = 0;
	if (decPart > 0.5) {
		returnNum =  Math.ceil((intPart + decPart)) / b;
	} else {
		returnNum =  Math.floor((intPart + decPart)) / b;
	}
	return returnNum;
};

/**
 * Return a number rounded to specified significant figures
 * 
 * @method sigFigs
 * @param {number} n the number to be rounded
 * @param {number} sig the number of significant figures to be rounded to
 * @return {number} retVal the rounded number
 */
PruMath.sigFigs = function(n, sig) {
	var negNum = false;
	if (n == 0) {
		return 0;
	} else if (n < 0) {
		negNum = true;
		n = n * -1;
	}
	
	var nInt = parseInt(n);
    var nStr = nInt.toString();
    
    if (nStr.length <= sig){
        return nInt;
    }
    
    for (var i=sig; i<nStr.length; i++){
        nStr = PruMath.setCharAt(nStr,i,'0');
    }   
    
    var retVal = parseInt(nStr);
	if (negNum) {
		return 0 - retVal;
	} 
	
	return retVal;
};

PruMath.setCharAt = function(str,index,chr) {
    if(index > str.length-1) {
    	return str;
    }
    return str.substr(0,index) + chr + str.substr(index+1);
};

PruMath.roundUpAtHalfPence=function(a){
	var b = a,
		c = (b * 100).toFixed(5),
		intPart = Math.floor(c), 
		decPart = (c - intPart),
		returnNum = 0;
	if (decPart >= 0.5) {
		returnNum = Math.ceil(intPart + decPart);
	  } else {
	    returnNum = Math.floor(intPart + decPart);
	  }
	return (returnNum/100); 
};

PruMath.roundDownAtHalfPence=function(a){
	var b = a,
		c = (b * 100).toFixed(5),
		intPart = Math.floor(c), 
		decPart = (c - intPart),
		returnNum = 0;
	if (decPart <= 0.5) {
		returnNum = Math.floor(intPart + decPart);
	  } else {
	    returnNum = Math.ceil(intPart + decPart);
	  }
	return (returnNum/100); 
};

/**
 * Added by Davendra - Required for Tax Relief Modeller - Match Excel's Roundup function
 * 
 * @method roundUpExcel
 * @param {number} value The value to be formatted
 * @param {digit} value The number decimals places
 * @return {number} The return value
 */
PruMath.roundUpExcel=function(number, digits){
    var factor = Math.pow(10,digits);
    return Math.ceil(number*factor) / factor;
};

/**
 * Added by Davendra - Required for Tax Relief Modeller - Match Excel's RoundDown function
 * 
 * @method roundDownExcel
 * @param {number} value The value to be formatted
 * @param {digit} value The number decimals places
 * @return {number} The return value
 */

PruMath.roundDownExcel=function(number, digits){
    if (number >= 0) {
        return Math.floor(number * Math.pow(10, digits)) / Math.pow(10, digits);
    } else {
    	return Math.ceil(number * Math.pow(10, digits)) / Math.pow(10, digits);
    }
};

// -- Formatting functions ----------------------------------------- //
	function PruFormat() {
	};
	
	/**
	 * Format a number in financial format. The result has commas separating each set of 3 digits and is returned as a sting
	 * 
	 * @method financialFormat
	 * @param {number} value The value to be formatted
	 * @return {string} The value in financial format
	 */
	PruFormat.financialFormat = function(value, symbol) {
		var negative = false;
		
		if (!value) {
			value = 0;
		}
		if (value < 0 && symbol == "pound") {
			negative = true;
			value = value * -1;
			//value = value.toFixed(2); // Ensures trailing zeros don't get cut off, ie. 5.20 * -1 = -5.2 !! 
		}
		
		var numberStr = value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
		if (symbol == "percent") {
			numberStr = numberStr + "%";
		}else if (symbol == "pound"){
			if (negative) {
				numberStr = "- &pound;" + numberStr;
			} else {
				numberStr = "&pound;" + numberStr;
			}
		}
		return numberStr;
	};
	
	/**
	 * Format a number in financial format. The result has commas separating each set of 3 digits and is returned as a sting
	 * The resultant number is formatted with two decimal places
	 * @method financialFormatDecimal
	 * @param {number} value The value to be formatted
	 * @return {string} The value in financial format
	 */
	PruFormat.financialFormatDecimal = function(value, symbol) {
		var negative = false;
		
		if (!value) {
			value = 0;
		}
    
    
		if (value < 0 && symbol == "pound") {
			negative = true;
			value = value * -1;
		}
		
		value = parseFloat(value).toFixed(2);
    
		var numberStr = value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
		if (symbol == "percent") {
			numberStr = numberStr + "%";
		}else if (symbol == "pound"){
			if (negative) {
				numberStr = "- &pound;" + numberStr;
			} else {
				numberStr = "&pound;" + numberStr;
			}
		}
		return numberStr;
	};
// ----------------------------------------------------------------- //

